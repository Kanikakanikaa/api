import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Formm from './component/form';
import Get from './component/get';


function App() {
  return (
    <>
   <Formm/> 
   <Get/>
   </>
  )
}

export default App;
